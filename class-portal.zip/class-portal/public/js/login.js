function login() {
    const name = document.getElementById("nameInput").value.trim();
    const password = document.getElementById("passInput").value.trim();
    const agreed = document.getElementById("agreeBox").checked;
    const error = document.getElementById("error");

    if (!name || !password) {
        error.innerText = "����д������Ϣ";
        return;
    }

    if (!agreed) {
        error.innerText = "�빴ѡͬ���û�Э��";
        return;
    }

    fetch('/api/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, password })
    })
        .then(res => res.json())
        .then(data => {
            if (data.success) {
                localStorage.setItem("user", JSON.stringify(data.user));
                location.href = "index.html";
            } else {
                error.innerText = "��¼ʧ�ܣ�" + data.message;
            }
        })
        .catch(err => {
            console.error("��¼�������", err);
            error.innerText = "��������������";
        });
}
