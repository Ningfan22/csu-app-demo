﻿const user = JSON.parse(localStorage.getItem("user"));
if (!user || user.studentId !== "2025001") {
    alert("无权访问：仅管理员可查看！");
    location.href = "index.html";
}

let allUsers = [];
let financeData = [];
let complaints = [];

document.addEventListener("DOMContentLoaded", () => {
    loadUsers();
    loadFinance();
    loadComplaints();
});

// 👥 用户管理
function loadUsers() {
    fetch("/api/users")
        .then(res => res.json())
        .then(data => {
            allUsers = data;
            const tbody = document.getElementById("userTable");
            tbody.innerHTML = "";
            data.forEach((u, i) => {
                const tr = document.createElement("tr");
                tr.innerHTML = `
          <td>${u.name}</td>
          <td>${u.studentId}</td>
          <td>${u.online ? "在线" : "离线"}</td>
          <td>${u.studentId === "2025001" ? "管理员" : `<button onclick="delUser(${i})">删除</button>`}</td>
        `;
                tbody.appendChild(tr);
            });
        });
}

function addUser() {
    const name = document.getElementById("addName").value.trim();
    const id = document.getElementById("addId").value.trim();
    if (!name || !id) return alert("请输入姓名和学号");

    if (allUsers.find(u => u.studentId === id)) {
        return alert("学号已存在！");
    }

    allUsers.push({
        name,
        studentId: id,
        password: id,
        college: "建筑与艺术学院",
        major: "艺术与科技",
        class: "艺科2404",
        avatar: "default.png",
        online: false
    });

    fetch("/api/users", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(allUsers)
    }).then(() => {
        alert("添加成功");
        loadUsers();
    });
}

function delUser(index) {
    if (!confirm("确认删除该用户？")) return;
    allUsers.splice(index, 1);
    fetch("/api/users", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(allUsers)
    }).then(loadUsers);
}

// 💰 班费管理
function loadFinance() {
    fetch("/api/finance")
        .then(res => res.json())
        .then(data => {
            financeData = data;
            document.getElementById("newBalance").value = data.balance;
        });
}

function adjustBalance() {
    const newVal = parseFloat(document.getElementById("newBalance").value);
    if (isNaN(newVal)) return alert("请输入正确的数字");

    financeData.balance = newVal;
    financeData.log.push({
        type: "adjust",
        content: `班费余额调整为：¥${newVal.toFixed(2)}`,
        time: new Date().toLocaleString()
    });

    fetch("/api/finance", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(financeData)
    })
        .then(() => {
            // 自动生成公告
            return fetch("/api/announcements")
                .then(res => res.json())
                .then(list => {
                    list.unshift({
                        title: "班费更新",
                        content: `管理员将班费余额调整为 ¥${newVal.toFixed(2)}`,
                        pinned: false,
                        time: new Date().toLocaleString(),
                        deleted: false
                    });
                    return fetch("/api/announcements", {
                        method: "POST",
                        headers: { "Content-Type": "application/json" },
                        body: JSON.stringify(list)
                    });
                });
        })
        .then(() => {
            alert("已更新班费并发布公告");
        });
}

// 📝 留言管理
function loadComplaints() {
    fetch("/api/complaints")
        .then(res => res.json())
        .then(data => {
            complaints = data;
            const ul = document.getElementById("complaintsList");
            ul.innerHTML = "";
            data.forEach((c, i) => {
                const li = document.createElement("li");
                li.innerHTML = `
          <b>${c.anonymous ? "匿名用户" : c.name}</b>：${c.message}
          <br><small>${c.time}</small>
          <button onclick="deleteComplaint(${i})">删除</button>
        `;
                ul.appendChild(li);
            });
        });
}

function deleteComplaint(index) {
    if (!confirm("确认删除该留言？")) return;
    complaints.splice(index, 1);
    fetch("/api/complaints", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(complaints)
    }).then(loadComplaints);
}
