document.addEventListener("DOMContentLoaded", () => {
    const user = JSON.parse(localStorage.getItem("user"));
    if (!user) location.href = "login.html";

    if (user.studentId === "2025001") {
        document.getElementById("adminButtons").style.display = "inline";
    }

    document.getElementById("searchInput").addEventListener("input", e => {
        const keyword = e.target.value.trim().toLowerCase();
        fetch("/api/announcements")
            .then(res => res.json())
            .then(data => {
                const filtered = data.filter(a =>
                    !a.deleted && (
                        a.title.toLowerCase().includes(keyword) ||
                        a.content.toLowerCase().includes(keyword)
                    )
                );
                renderAnnouncements(filtered);
            });
    });

    loadAnnouncements();
});

function openNewAnn() {
    document.getElementById("newAnnModal").style.display = "flex";
}

function closeNewAnn() {
    document.getElementById("newAnnModal").style.display = "none";
}

function submitAnn() {
    const title = document.getElementById("annTitle").value.trim();
    const content = document.getElementById("annContent").value.trim();
    const pinned = document.getElementById("isPinned").checked;

    if (!title || !content) return alert("����д����������Ϣ");

    fetch("/api/announcements")
        .then(res => res.json())
        .then(data => {
            data.unshift({
                title,
                content,
                pinned,
                time: new Date().toLocaleString(),
                deleted: false
            });
            return fetch("/api/announcements", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(data)
            });
        })
        .then(() => {
            closeNewAnn();
            loadAnnouncements();
        });
}

function deleteAnn(index) {
    if (!confirm("ȷ��ɾ���ù��棿")) return;
    fetch("/api/announcements")
        .then(res => res.json())
        .then(data => {
            data[index].deleted = true;
            return fetch("/api/announcements", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(data)
            });
        })
        .then(loadAnnouncements);
}

function renderAnnouncements(data) {
    const user = JSON.parse(localStorage.getItem("user"));
    const list = document.getElementById("annList");
    list.innerHTML = "";

    data
        .map((a, i) => ({ ...a, i }))
        .filter(a => !a.deleted)
        .sort((a, b) => (b.pinned - a.pinned) || b.time.localeCompare(a.time))
        .forEach(a => {
            const div = document.createElement("div");
            div.className = "announcement" + (a.pinned ? " pinned" : "");
            div.innerHTML = `
        <h3>${a.title}</h3>
        <p>${a.content}</p>
        <div class="time">${a.time}</div>
        ${user.studentId === "2025001"
                    ? `<button onclick="deleteAnn(${a.i})">ɾ��</button>`
                    : ""
                }
      `;
            list.appendChild(div);
        });
}

function loadAnnouncements() {
    fetch("/api/announcements")
        .then(res => res.json())
        .then(renderAnnouncements);
}
