﻿let financeData = {};
const user = JSON.parse(localStorage.getItem("user"));
const isAdmin = user && user.studentId === "2025001";

if (!user) location.href = "login.html";

document.addEventListener("DOMContentLoaded", () => {
    if (isAdmin) {
        document.getElementById("adminArea").style.display = "block";
    }
    loadFinance();
});

function loadFinance() {
    fetch("/api/finance")
        .then(res => res.json())
        .then(data => {
            financeData = data;
            document.getElementById("balance").innerText = data.balance.toFixed(2);
            renderLog(data.log);
            if (isAdmin) renderRequests(data.requests);
        });
}

function renderLog(log) {
    const list = document.getElementById("logList");
    list.innerHTML = "";
    log.slice().reverse().forEach(entry => {
        const li = document.createElement("li");
        if (entry.type === "adjust") {
            li.innerText = `[${entry.time}] 管理员调整余额：${entry.content}`;
        } else {
            li.innerText = `[${entry.time}] ${entry.name} 使用 ¥${entry.amount} - ${entry.reason}（${entry.approved ? "已批准" : "未批准"}）`;
        }
        list.appendChild(li);
    });
}

function renderRequests(requests) {
    const reqList = document.getElementById("requestList");
    reqList.innerHTML = "";
    requests
        .filter(r => r.status === "pending")
        .forEach((r, i) => {
            const li = document.createElement("li");
            li.innerHTML = `
        ${r.name} 申请 ¥${r.amount} - ${r.reason}
        <button onclick="approve(${i})">批准</button>
        <button onclick="reject(${i})">拒绝</button>
      `;
            reqList.appendChild(li);
        });
}

function submitRequest() {
    const amount = parseFloat(document.getElementById("applyAmount").value);
    const reason = document.getElementById("applyReason").value.trim();
    if (!amount || !reason) return alert("请填写完整申请信息");

    financeData.requests.push({
        studentId: user.studentId,
        name: user.name,
        amount,
        reason,
        time: new Date().toLocaleString(),
        status: "pending"
    });

    saveFinance("已提交申请");
}

function approve(index) {
    const req = financeData.requests[index];
    if (financeData.balance < req.amount) return alert("余额不足");

    req.status = "approved";
    financeData.balance -= req.amount;
    financeData.log.push({
        type: "use",
        studentId: req.studentId,
        name: req.name,
        amount: req.amount,
        reason: req.reason,
        approved: true,
        time: new Date().toLocaleString()
    });

    saveFinance("已批准");
}

function reject(index) {
    financeData.requests.splice(index, 1);
    saveFinance("已拒绝申请");
}

function adjustBalance() {
    const newVal = parseFloat(document.getElementById("newBalance").value);
    if (isNaN(newVal)) return alert("请输入正确的数字");

    financeData.balance = newVal;
    financeData.log.push({
        type: "adjust",
        content: "班费余额调整为：" + newVal.toFixed(2),
        time: new Date().toLocaleString()
    });

    saveFinance("已更新余额");
}

function saveFinance(msg) {
    fetch("/api/finance", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(financeData)
    }).then(() => {
        alert(msg);
        loadFinance();
    });
}
