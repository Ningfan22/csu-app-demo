﻿document.addEventListener("DOMContentLoaded", () => {
    const user = JSON.parse(localStorage.getItem("user"));
    if (!user) return location.href = "login.html";

    // ✅ 用户头像与姓名显示
    document.getElementById("username").innerText = user.name;
    document.getElementById("avatar").src = "avatars/" + (user.avatar || "default.png");

    // ✅ 登出功能
    document.getElementById("logoutBtn").onclick = () => {
        fetch("/api/logout", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ studentId: user.studentId })
        }).then(() => {
            localStorage.clear();
            location.href = "login.html";
        });
    };

    // ✅ 管理员身份识别
    if (user.studentId === "2025001") {
        const adminBtn = document.getElementById("adminBtn");
        adminBtn.style.display = "inline-block";
        adminBtn.onclick = () => location.href = "manage_users.html";
    }

    // ✅ 公告加载默认 3 条
    loadAnnouncements();

    // ✅ 搜索功能监听
    document.getElementById("searchInput").addEventListener("input", e => {
        const keyword = e.target.value.trim().toLowerCase();
        fetch("/api/announcements")
            .then(res => res.json())
            .then(data => {
                const matched = data
                    .filter(a =>
                        !a.deleted &&
                        (a.title.toLowerCase().includes(keyword) ||
                            a.content.toLowerCase().includes(keyword))
                    )
                    .slice(0, 3);
                renderAnnouncements(matched);
            });
    });

    // ✅ 留言红点提醒
    checkUnreadMessages();
});

// 渲染公告区域
function loadAnnouncements() {
    fetch("/api/announcements")
        .then(res => res.json())
        .then(data => {
            const recent = data
                .filter(a => !a.deleted)
                .sort((a, b) => (b.pinned - a.pinned) || b.time.localeCompare(a.time))
                .slice(0, 3);
            renderAnnouncements(recent);
        });
}

function renderAnnouncements(list) {
    const box = document.getElementById("announcementList");
    box.innerHTML = "";
    list.forEach(a => {
        const div = document.createElement("div");
        div.className = "announcement";
        div.innerHTML = `
      <h4>${a.title}</h4>
      <p>${a.content}</p>
      <div class="time">${a.time}</div>
    `;
        box.appendChild(div);
    });
}

// 检查是否有未读留言 → 红点提醒
function checkUnreadMessages() {
    const user = JSON.parse(localStorage.getItem("user"));
    fetch("/api/messages")
        .then(res => res.json())
        .then(data => {
            const unread = data.some(m => m.to === user.studentId && !m.read);
            if (unread) {
                const btn = document.getElementById("messageBtn");
                btn.innerHTML = `<i class="fas fa-comment-dots"></i><span>留言 🔴</span>`;
            }
        })
        .catch(err => {
            console.error("留言检测失败：", err);
        });
}
