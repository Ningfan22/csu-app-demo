let user = JSON.parse(localStorage.getItem("user"));
if (!user) location.href = "login.html";

document.addEventListener("DOMContentLoaded", () => {
    document.getElementById("avatarPreview").src = "avatars/" + (user.avatar || "default.png");
    document.getElementById("nameText").innerText = user.name;
    document.getElementById("idText").innerText = user.studentId;
    document.getElementById("collegeInput").value = user.college;
    document.getElementById("majorInput").value = user.major;
    document.getElementById("classInput").value = user.class;
});

function uploadAvatar() {
    const file = document.getElementById("avatarFile").files[0];
    if (!file) return alert("��ѡ��ͼƬ");

    const form = new FormData();
    form.append("avatar", file);
    form.append("studentId", user.studentId);

    fetch("/api/upload-avatar", { method: "POST", body: form })
        .then(res => res.json())
        .then(data => {
            if (data.success) {
                user.avatar = data.filename;
                localStorage.setItem("user", JSON.stringify(user));
                document.getElementById("avatarPreview").src = "avatars/" + data.filename;
                updateUserField("avatar", data.filename);
            }
        });
}

function saveProfile() {
    const college = document.getElementById("collegeInput").value;
    const major = document.getElementById("majorInput").value;
    const cls = document.getElementById("classInput").value;

    updateUserField("college", college);
    updateUserField("major", major);
    updateUserField("class", cls);
}

function updateUserField(field, value) {
    fetch("/api/users")
        .then(res => res.json())
        .then(users => {
            const target = users.find(u => u.studentId === user.studentId);
            if (target) {
                target[field] = value;
                user[field] = value;
                localStorage.setItem("user", JSON.stringify(user));
                return fetch("/api/users", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify(users)
                });
            }
        });
}

function changePassword() {
    const old = document.getElementById("oldPass").value;
    const np = document.getElementById("newPass").value;
    if (!old || !np) return alert("����д��������");

    fetch("/api/users")
        .then(res => res.json())
        .then(users => {
            const target = users.find(u => u.studentId === user.studentId);
            if (target && target.password === old) {
                target.password = np;
                user.password = np;
                localStorage.setItem("user", JSON.stringify(user));
                return fetch("/api/users", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify(users)
                }).then(() => alert("�������޸�"));
            } else {
                alert("��ǰ���벻��ȷ");
            }
        });
}
