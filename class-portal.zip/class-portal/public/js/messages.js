let allMessages = [];
let currentTarget = null;
const user = JSON.parse(localStorage.getItem("user"));

if (!user) location.href = "login.html";

document.addEventListener("DOMContentLoaded", () => {
    document.getElementById("targetInput").addEventListener("change", e => {
        currentTarget = e.target.value.trim();
        if (currentTarget.length > 0) renderChat(currentTarget);
    });

    document.getElementById("msgInput").addEventListener("keydown", e => {
        if (e.key === "Enter" && !e.shiftKey) {
            e.preventDefault();
            sendMsg();
        }
    });

    loadMessages();
});

function loadMessages() {
    fetch('/api/messages')
        .then(res => res.json())
        .then(data => {
            allMessages = data;
            if (currentTarget) renderChat(currentTarget);
        });
}

function renderChat(targetId) {
    const chat = document.getElementById("chatBox");
    chat.innerHTML = "";
    const dialog = allMessages.filter(m =>
        (m.from === user.studentId && m.to === targetId) ||
        (m.to === user.studentId && m.from === targetId)
    );

    dialog.forEach(m => {
        const div = document.createElement("div");
        div.className = "message " + (m.from === user.studentId ? "sent" : "received");
        div.innerHTML = `
      ${m.anonymous && m.from !== user.studentId ? "<i>����</i><br>" : ""}
      ${m.message}<br><span style="font-size:0.7em;color:#666">${m.time}</span>
    `;
        chat.appendChild(div);
    });

    chat.scrollTop = chat.scrollHeight;
}

function sendMsg() {
    const text = document.getElementById("msgInput").value.trim();
    const target = document.getElementById("targetInput").value.trim();
    const isAnonymous = document.getElementById("isAnonymous").checked;

    if (!text || !target) return alert("����дѧ������������");

    allMessages.push({
        from: user.studentId,
        to: target,
        anonymous: isAnonymous,
        message: text,
        time: new Date().toLocaleString(),
        read: false
    });

    fetch("/api/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(allMessages)
    }).then(() => {
        document.getElementById("msgInput").value = "";
        renderChat(target);
    });
}
