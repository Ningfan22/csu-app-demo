const user = JSON.parse(localStorage.getItem("user"));
if (!user) location.href = "login.html";
const isAdmin = user.studentId === "2025001";

document.addEventListener("DOMContentLoaded", () => {
    loadComplaints();
});

function loadComplaints() {
    fetch("/api/complaints")
        .then(res => res.json())
        .then(data => {
            const adminBox = document.getElementById("adminView");
            const userBox = document.getElementById("userView");
            const allList = document.getElementById("complaintsList");
            const myList = document.getElementById("myComplaintsList");

            allList.innerHTML = "";
            myList.innerHTML = "";

            data.forEach((c, i) => {
                const li = document.createElement("li");
                const name = c.anonymous ? "�����û�" : c.name;
                li.innerHTML = `<b>${name}</b>��${c.message}<br><small>${c.time}</small>`;

                if (isAdmin) {
                    const del = document.createElement("button");
                    del.innerText = "ɾ��";
                    del.onclick = () => {
                        data.splice(i, 1);
                        fetch("/api/complaints", {
                            method: "POST",
                            headers: { "Content-Type": "application/json" },
                            body: JSON.stringify(data)
                        }).then(loadComplaints);
                    };
                    li.appendChild(del);
                    adminBox.style.display = "block";
                    allList.appendChild(li);
                }

                if (c.from === user.studentId) {
                    userBox.style.display = "block";
                    myList.appendChild(li.cloneNode(true));
                }
            });
        });
}

function submitComplaint() {
    const msg = document.getElementById("complaintInput").value.trim();
    const anonymous = document.getElementById("anonymous").checked;
    if (!msg) return alert("���ݲ���Ϊ��");

    fetch("/api/complaints")
        .then(res => res.json())
        .then(data => {
            data.push({
                from: user.studentId,
                name: user.name,
                anonymous,
                message: msg,
                time: new Date().toLocaleString()
            });
            return fetch("/api/complaints", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(data)
            });
        }).then(() => {
            alert("�ύ�ɹ�");
            document.getElementById("complaintInput").value = "";
            loadComplaints();
        });
}
