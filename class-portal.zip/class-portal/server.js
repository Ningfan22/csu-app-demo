﻿const express = require('express');
const fs = require('fs');
const path = require('path');
const multer = require('multer');

const app = express();
const PORT = 3000;

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// ✅ 静态资源托管：支持 HTML、JS、CSS、图片等
app.use(express.static(path.join(__dirname, 'public')));

// 📁 数据文件路径
const DATA_DIR = path.join(__dirname, 'public', 'data');

// 🔄 工具函数：读取 / 写入 JSON 文件
function readJSON(file) {
    return JSON.parse(fs.readFileSync(path.join(DATA_DIR, file), 'utf-8'));
}
function writeJSON(file, data) {
    fs.writeFileSync(path.join(DATA_DIR, file), JSON.stringify(data, null, 2), 'utf-8');
}

// 🧩 登录接口
app.post('/api/login', (req, res) => {
    try {
        const { name, password } = req.body;
        const users = readJSON('users.json'); // 这里若文件损坏会报错
        const found = users.find(u => u.name === name && u.password === password);
        if (found) {
            found.online = true;
            writeJSON('users.json', users);
            res.json({ success: true, user: found });
        } else {
            res.json({ success: false, message: '用户名或密码错误' });
        }
    } catch (err) {
        console.error("登录接口出错：", err);
        res.status(500).json({ success: false, message: "服务器内部错误，请检查 users.json 是否存在或格式错误" });
    }
});

// ⛔ 登出接口
app.post('/api/logout', (req, res) => {
    const { studentId } = req.body;
    const users = readJSON('users.json');
    const found = users.find(u => u.studentId === studentId);
    if (found) {
        found.online = false;
        writeJSON('users.json', users);
    }
    res.json({ success: true });
});

// 🗂 用户管理
app.get('/api/users', (req, res) => {
    res.json(readJSON('users.json'));
});
app.post('/api/users', (req, res) => {
    writeJSON('users.json', req.body);
    res.json({ success: true });
});

// 📢 公告管理
app.get('/api/announcements', (req, res) => {
    res.json(readJSON('announcements.json'));
});
app.post('/api/announcements', (req, res) => {
    writeJSON('announcements.json', req.body);
    res.json({ success: true });
});

// 💬 私聊留言
app.get('/api/messages', (req, res) => {
    res.json(readJSON('messages.json'));
});
app.post('/api/messages', (req, res) => {
    writeJSON('messages.json', req.body);
    res.json({ success: true });
});

// 📣 投诉留言
app.get('/api/complaints', (req, res) => {
    res.json(readJSON('complaints.json'));
});
app.post('/api/complaints', (req, res) => {
    writeJSON('complaints.json', req.body);
    res.json({ success: true });
});

// 💰 班费管理
app.get('/api/finance', (req, res) => {
    res.json(readJSON('finance.json'));
});
app.post('/api/finance', (req, res) => {
    writeJSON('finance.json', req.body);
    res.json({ success: true });
});

// 🖼️ 头像上传
const storage = multer.diskStorage({
    destination: path.join(__dirname, 'public', 'avatars'),
    filename: (req, file, cb) => {
        const ext = path.extname(file.originalname);
        cb(null, req.body.studentId + ext);
    }
});
const upload = multer({ storage });

app.post('/api/upload-avatar', upload.single('avatar'), (req, res) => {
    res.json({ success: true, filename: req.file.filename });
});

// 🚪 默认路由 → login 页面
app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'login.html'));
});

// 🚀 启动服务器
app.listen(PORT, () => {
    console.log(`✅ 服务器已启动： http://localhost:${PORT}`);
});
